#! /bin/sh

sudo cp /etc/dhcpcd_ap.conf /etc/dhcpcd.conf && 
sudo systemctl enable hostapd dnsmasq && 
sudo systemctl start hostapd dnsmasq && 
sudo nohup sh -c 'ip addr flush dev wlan0 && 
sudo systemctl restart dhcpcd.service'  >/dev/null && 
sudo reboot now &